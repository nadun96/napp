# Run the code

```
npm install
npm start
```
